/**
 * @license
 * Cesium - https://github.com/CesiumGS/cesium
 * Version 1.117
 *
 * Copyright 2011-2022 Cesium Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Columbus View (Pat. Pend.)
 *
 * Portions licensed separately.
 * See https://github.com/CesiumGS/cesium/blob/main/LICENSE.md for full licensing details.
 */

import {
  PrimitivePipeline_default
} from "./chunk-PWF3YJJ5.js";
import {
  createTaskProcessorWorker_default
} from "./chunk-IBXGK4WV.js";
import "./chunk-WEGCQ5DY.js";
import "./chunk-PK7TEP3J.js";
import "./chunk-PS6AEMBR.js";
import "./chunk-AOFMPKUB.js";
import "./chunk-G7CJQKKD.js";
import "./chunk-FOZQIHZK.js";
import "./chunk-WWP3I7R5.js";
import "./chunk-RL73GOEF.js";
import "./chunk-34DGOKCO.js";
import "./chunk-NI2R52QD.js";
import "./chunk-I5TDPPC4.js";
import "./chunk-TMMOULW3.js";
import "./chunk-C5CE4OG6.js";
import "./chunk-4PHPQRSH.js";
import "./chunk-PEABJLCK.js";
import "./chunk-WFICTTOE.js";
import "./chunk-UCPPWV64.js";
import "./chunk-U4IMCOF5.js";
import "./chunk-BDUJXBVF.js";

// packages/engine/Source/Workers/combineGeometry.js
function combineGeometry(packedParameters, transferableObjects) {
  const parameters = PrimitivePipeline_default.unpackCombineGeometryParameters(
    packedParameters
  );
  const results = PrimitivePipeline_default.combineGeometry(parameters);
  return PrimitivePipeline_default.packCombineGeometryResults(
    results,
    transferableObjects
  );
}
var combineGeometry_default = createTaskProcessorWorker_default(combineGeometry);
export {
  combineGeometry_default as default
};
